from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Used to secure the session

DATABASE = 'feedback.db'

# Admin credentials
ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD = 'admin123'


def get_db():
    conn = sqlite3.connect(DATABASE)
    return conn


def init_db():
    conn = get_db()
    cur = conn.cursor()

    # Create the feedback table if it doesn't exist
    cur.execute('''
    CREATE TABLE IF NOT EXISTS feedback (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        floor INTEGER,
        feedback_type TEXT,
        comment TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    ''')

    conn.commit()
    conn.close()


@app.route('/')
def index():
    conn = get_db()
    cur = conn.cursor()

    # Fetch feedback counts for both floors
    cur.execute("SELECT floor, feedback_type, COUNT(*) FROM feedback GROUP BY floor, feedback_type")
    feedback_data = cur.fetchall()

    feedback_summary = {
        "ground_floor": {"excellent": 0, "good": 0, "bad": 0},
        "first_floor": {"excellent": 0, "good": 0, "bad": 0}
    }

    for row in feedback_data:
        floor = "ground_floor" if row[0] == 0 else "first_floor"
        feedback_type = row[1]
        count = row[2]
        feedback_summary[floor][feedback_type] = count

    return render_template('index.html', feedback_summary=feedback_summary)


@app.route('/submit_feedback', methods=['POST'])
def submit_feedback():
    feedback_type = request.form['feedback_type']
    floor = request.form['floor']
    comment = request.form.get('comment', '')

    conn = get_db()
    cur = conn.cursor()
    cur.execute("INSERT INTO feedback (floor, feedback_type, comment) VALUES (?, ?, ?)",
                (floor, feedback_type, comment))
    conn.commit()
    conn.close()

    return "Feedback received", 200


@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session['admin_logged_in'] = True
            return redirect(url_for('view_all_feedback'))
        else:
            flash('Invalid credentials. Please try again.')
            return redirect(url_for('admin_login'))
    return render_template('admin_login.html')


@app.route('/admin_logout')
def admin_logout():
    session.pop('admin_logged_in', None)
    return redirect(url_for('index'))


@app.route('/view_all_feedback', methods=['GET', 'POST'])
def view_all_feedback():
    if not session.get('admin_logged_in'):
        return redirect(url_for('admin_login'))

    conn = get_db()
    cur = conn.cursor()

    floor_filter = request.form.get('floor_filter')
    type_filter = request.form.get('type_filter')
    date_from = request.form.get('date_from')
    date_to = request.form.get('date_to')

    query = "SELECT floor, feedback_type, timestamp, comment FROM feedback WHERE 1=1"
    params = []

    if floor_filter:
        query += " AND floor = ?"
        params.append(floor_filter)

    if type_filter:
        query += " AND feedback_type = ?"
        params.append(type_filter)

    if date_from and date_to:
        query += " AND timestamp BETWEEN ? AND ?"
        params.append(date_from)
        params.append(date_to)

    query += " ORDER BY timestamp DESC"
    cur.execute(query, params)
    all_feedback = cur.fetchall()
    conn.close()

    return render_template('view_all_feedback.html', all_feedback=all_feedback)


if __name__ == '__main__':
    with app.app_context():
        init_db()
    app.run(host='0.0.0.0', debug=True)
