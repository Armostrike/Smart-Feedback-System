import sqlite3
con = sqlite3.connect('feedback.db')
con.execute("CREATE TABLE feedback (id INTEGER PRIMARY KEY AUTOINCREMENT, floor INTEGER NOT NULL, feedback_type TEXT NOT NULL,comment TEXT, timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)");
